chart_html_template_notebook = '''<html>
<head>
    <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="0">
    <meta charset="utf-8">
    <title>MobileSolutionWorkshop / MobileLösungsWerkstatt</title>
    <script src="<!-- #moloewe_server# --><!-- #moloewe_library_moloewe_path# -->jquery-3.6.0.min.js"></script>
    <script src="<!-- #moloewe_server# --><!-- #moloewe_library_echarts_path# -->echarts.min.js"></script>
    <script src="<!-- #moloewe_server# --><!-- #moloewe_library_echarts_path# -->echarts-stat/ecStat.min.js"></script>
    <script src="<!-- #moloewe_server# --><!-- #moloewe_library_echarts_path# -->echarts-gl.js"></script>
    <!-- chart external scripts -->
    <!-- #moloewe_external_scripts# -->
</head>
<body>
<!-- chart display area div -->
<div id="moloewe_chart_area" class="moloewe_chart_area"
     style="width: 100%; height: 650px; margin: 0px; padding: 0px"></div>

<script type="text/javascript">

    var moloewe_executed_in_moloewe = false;
    var moloewe_random = "<!-- #moloewe_random# -->";
    
    <!-- chart scripts preprocess -->
    <!-- #moloewe_scripts_preprocess# -->

    <!-- chart embedded data -->
    <!-- #moloewe_embedded_data# -->

    <!-- chart instance -->
    var moloewe_chart = echarts.init(document.getElementById('moloewe_chart_area'));

    <!-- chart scripts -->
    <!-- #moloewe_scripts# -->

    <!-- chart preset options -->
    var moloewe_preset_options = {};
    <!-- #moloewe_preset_options# -->
    
    <!-- chart options -->
    var moloewe_options = {};
    <!-- #moloewe_options# -->

    var moloewe_chart_options = $.extend(true, moloewe_preset_options, moloewe_options);

</script>

<!-- chart processing -->
<script src="<!-- #moloewe_server# --><!-- #moloewe_library_moloewe_path# -->moloewe-chart.js"></script>

<script type="text/javascript">

     <!-- chart show -->
    moloewe_chart.setOption(moloewe_chart_options);

    <!-- chart scripts postprocess -->
    <!-- #moloewe_scripts_postprocess# -->

</script>
</body>
</html>'''

chart_html_template_notebook_error = '''
<html>
<head>
    <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="0">
    <meta charset="utf-8">
    <title>MobileSolutionWorkshop / MobileLösungsWerkstatt</title>
</head>
<body>
    <!-- chart error message -->
    <h3 style="color: #FF0000";><!-- #moloewe_error_message# --></h3>
</body></html>
'''

# MoLöWe chart module

from os import path

# html template to render chart as tool in MoLöWe server
from moloewe_chart.chart_html_template_moloewe import chart_html_template_moloewe
# html template to render chart in JupyterHub notebook
from moloewe_chart.chart_html_template_notebook import chart_html_template_notebook
# html template to render error message in JupyterHub notebook
from moloewe_chart.chart_html_template_notebook_error import chart_html_template_notebook_error


class MoloeweChart:

    def __init__(self, moloewe_server_default=None):
        self.moloewe_server_default = moloewe_server_default if moloewe_server_default else 'https://moloewe.leuphana.de/'
        if path.exists('constants.py'):
            from constants import moloewe_server_setup
            self.moloewe_server_setup = moloewe_server_setup
        else:
            self.moloewe_server_setup = None
        self.moloewe_executed_in_moloewe = False

    # add data variable to python dictionary
    def moloewe_chart_add_embedded_data(self, my_embedded_data, my_variable, variable_data):
        # check if data my_variable exists in my_embedded_data python dict
        # add data my_variable as str element to my_embedded_data python dict if it does not exist
        if my_variable not in my_embedded_data.keys():
            my_embedded_data[my_variable] = str(variable_data)
        return my_embedded_data

    #  remove data variable from python dictionary
    def moloewe_chart_remove_embedded_data(self, my_embedded_data, my_variable):
        # check if data my_variable exists in my_embedded_data python dict
        # remove data my_variable from my_embedded_data python dict if it does not exist
        if my_variable in my_embedded_data.keys():
            del my_embedded_data[my_variable]
        return my_embedded_data

    #  update data variable in python dictionary
    def moloewe_chart_update_embedded_data(self, my_embedded_data, my_variable, variable_data):
        my_embedded_data = self.moloewe_chart_remove_embedded_data(my_embedded_data, my_variable)
        my_embedded_data = self.moloewe_chart_add_embedded_data(my_embedded_data, my_variable, variable_data)
        return my_embedded_data

    # add external script to python dictionary
    def moloewe_chart_add_external_script(self, my_external_scripts, script_path):
        # check if script_path exists in my_external_scripts python dict
        # add script_path as str element to my_external_scripts python dict if it does not exist
        if script_path not in my_external_scripts:
            my_external_scripts.append(script_path)
        return my_external_scripts

    #  remove external script from python dictionary
    def moloewe_chart_remove_external_script(self, my_external_scripts, script_path):
        # check if script_path exists in my_external_scripts python dict
        # remove script_path from my_external_scripts python dict if it does exist
        if script_path in my_external_scripts:
            my_external_scripts.remove(script_path)
        return my_external_scripts

    #  update external script in python dictionary
    def moloewe_chart_update_external_script(self, my_external_scripts, script_path):
        my_external_scripts = self.moloewe_chart_remove_externalscript(my_external_scripts, script_path)
        my_external_scripts = self.moloewe_chart_add_external_script(my_external_scripts, script_path)
        return my_external_scripts

    # render chart using html template files with provided charts data
    def moloewe_chart_plot(self, **kwargs):
        from IPython.display import HTML
        from inspect import getmembers
        import time
        import random
        import http.client
        from urllib.parse import urlparse

        # import embedded data variables into HTML as javascript variables
        moloewe_embedded_data = []
        if 'chart_embedded_data' in kwargs:
            for key, value in kwargs['chart_embedded_data'].items():
                moloewe_embedded_data.append('''var ''' + key + ''' = ''' + value + '''; ''')

        # import preset chart options (string variable like JSON that will be used as part of the chart settings)
        # moloewe_preset_options = kwargs['chart_preset_options'] if 'chart_preset_options' in kwargs else ''
        moloewe_preset_options = f"moloewe_preset_options = {kwargs['chart_preset_options']}" if 'chart_preset_options' in kwargs else ''
        # import chart scripts (javascripts that will be executed as part of the rendering)
        moloewe_scripts = kwargs['chart_scripts'] if 'chart_scripts' in kwargs else ''
        # import chart preprocess scripts (javascripts that will be executed BEFORE the rendering of the chart)
        moloewe_scripts_preprocess = kwargs['chart_scripts_preprocess'] if 'chart_scripts_preprocess' in kwargs else ''
        # import chart preprocess scripts (javascripts that will be executed AFTER the rendering of the chart)
        moloewe_scripts_postprocess = kwargs[
            'chart_scripts_postprocess'] if 'chart_scripts_postprocess' in kwargs else ''
        # import chart options (python dict exported as JSON variable that will be used as part of the chart settings)
        moloewe_options = f"moloewe_options = {self.moloewe_chart_convert_options_json(kwargs['chart_options'])}" if 'chart_options' in kwargs else ''
        # import external chart scripts (javascript files that will be loaded and executed as part of the rendering)
        chart_external_scripts = kwargs['chart_external_scripts'] if 'chart_external_scripts' in kwargs else ''

        # import chart data for plotly
        plotly_data = kwargs['plotly_data'] if 'plotly_data' in kwargs else ''
        # import chart config for plotly
        plotly_config = kwargs['plotly_config'] if 'plotly_config' in kwargs else ''

        # determine if plot is using plotly or echarts
        # set echarts as default
        chart_library = 'plotly' if plotly_data else 'echarts'

        # create chart data using echarts
        if chart_library == 'echarts':

            # define location paths of libraries that will be used
            moloewe_library_echarts_path = '/assets/libraries/echarts/'
            moloewe_library_moloewe_path = '/assets/libraries/moloewe/'

            # define html template for error message during preview in JupyterLab

            # define server from where to load template/libraries/themes
            # set absolute fall-back setting
            moloewe_server = 'https://moloewe.leuphana.de'
            # set to detect if function is executed in MoLöWe environment or in JupyterHub - this helps to select the correct html template
            # check if moloewe server is defined in the setup and/or in the notebook and not empty and choose correct server (_setup overrides _default)
            if self.moloewe_server_default:
                moloewe_server = self.moloewe_server_default

            if self.moloewe_server_setup:
                moloewe_server = self.moloewe_server_setup
                self.moloewe_executed_in_moloewe = True

            # create a timestamp value to prevent the browser from caching the output
            moloewe_random = str(random.randint(1, int(time.time())))

            # choose template based on environment the function is called from
            chart_html_template = chart_html_template_notebook
            if self.moloewe_executed_in_moloewe:
                chart_html_template = chart_html_template_moloewe

            # initialize error message text
            moloewe_error_message = ''

            # for execution in JupyterHub (that is previewing the chart)
            if not self.moloewe_executed_in_moloewe:

                # parse server info for scheme and domain
                moloewe_url = urlparse(moloewe_server)

                # insert external script sources into html template
                for idx, item in enumerate(chart_external_scripts):
                    chart_external_scripts[idx] = f'<script src="{item}"></script>'
                tmp_string = ''''''
                tmp_string = tmp_string.join(map(str, chart_external_scripts))
                chart_html_template = chart_html_template.replace('<!-- #moloewe_external_scripts# -->',
                                                                  str(tmp_string))
                try:
                    # check if server and library paths are reachable
                    # choose connection based on scheme
                    if moloewe_url.scheme == 'https':
                        moloewe_server_connection = http.client.HTTPSConnection(moloewe_url.netloc)
                    else:
                        moloewe_server_connection = http.client.HTTPConnection(moloewe_url.netloc)
                    # check if server itself is reachable
                    moloewe_server_connection.request("HEAD", '')
                    moloewe_server_status = moloewe_server_connection.getresponse().status
                    # check for error and create error message text
                    if not moloewe_server_status == 200:
                        chart_html_template = chart_html_template_notebook_error
                        moloewe_error_message = 'Error: ' + str(
                            moloewe_server_status) + ' Could not reach server ' + moloewe_server + ' to preview chart.'
                        # insert error message into html template
                        tmp_string = ''''''
                        tmp_string = tmp_string.join(map(str, moloewe_error_message))
                        chart_html_template = chart_html_template.replace('<!-- #moloewe_error_message# -->',
                                                                          str(tmp_string))

                        # generate html output
                        html_output = getmembers(HTML(chart_html_template))
                        # generate return result
                        return_output = dict(html_output)['__dict__']['data']

                        # return the data (in this case the error message) as well as the setting for which library to use
                        return {'chart_library': chart_library, 'data': return_output,
                                'chart_external_scripts': chart_external_scripts}
                except Exception as ex:
                    chart_html_template = chart_html_template_notebook_error
                    # create create error message text for exception
                    moloewe_error_message = 'Error: ' + str(
                        ex) + ' Trying to contact server ' + moloewe_server + ' to preview chart raised an exception.'
                    # insert error message into html template
                    tmp_string = ''''''
                    tmp_string = tmp_string.join(map(str, moloewe_error_message))
                    chart_html_template = chart_html_template.replace('<!-- #moloewe_error_message# -->',
                                                                      str(tmp_string))

                    # generate html output
                    html_output = getmembers(HTML(chart_html_template))
                    # generate return result
                    return_output = dict(html_output)['__dict__']['data']

                    # return the data (in this case the error message) as well as the setting for which library to use
                    return {'chart_library': chart_library, 'data': return_output,
                            'chart_external_scripts': chart_external_scripts}
                try:
                    # check if server and library paths are reachable
                    # choose connection based on scheme
                    if moloewe_url.scheme == 'https':
                        moloewe_server_connection = http.client.HTTPSConnection(moloewe_url.netloc)
                    else:
                        moloewe_server_connection = http.client.HTTPConnection(moloewe_url.netloc)
                    # check if server and echarts library path are reachable
                    moloewe_server_connection.request("HEAD", moloewe_library_echarts_path + 'echarts.min.js')
                    moloewe_server_status = moloewe_server_connection.getresponse().status
                    # check for error and create error message text
                    if not moloewe_server_status == 200:
                        chart_html_template = chart_html_template_notebook_error
                        moloewe_error_message = 'Error: ' + str(
                            moloewe_server_status) + ' Could not verify that server ' + moloewe_server + ' has chart library installed.'
                        # insert error message into html template
                        tmp_string = ''''''
                        tmp_string = tmp_string.join(map(str, moloewe_error_message))
                        chart_html_template = chart_html_template.replace('<!-- #moloewe_error_message# -->',
                                                                          str(tmp_string))

                        # generate html output
                        html_output = getmembers(HTML(chart_html_template))
                        # generate return result
                        return_output = dict(html_output)['__dict__']['data']

                        # return the data (in this case the error message) as well as the setting for which library to use
                        return {'chart_library': chart_library, 'data': return_output,
                                'chart_external_scripts': chart_external_scripts}
                except Exception as ex:
                    chart_html_template = chart_html_template_notebook_error
                    # create create error message text for exception
                    moloewe_error_message = 'Error: ' + str(
                        ex) + ' Trying to contact server ' + moloewe_server + moloewe_library_echarts_path + 'echarts.min.js to preview chart raised an exception.'
                    # insert error message into html template
                    tmp_string = ''''''
                    tmp_string = tmp_string.join(map(str, moloewe_error_message))
                    chart_html_template = chart_html_template.replace('<!-- #moloewe_error_message# -->',
                                                                      str(tmp_string))

                    # generate html output
                    html_output = getmembers(HTML(chart_html_template))
                    # generate return result
                    return_output = dict(html_output)['__dict__']['data']

                    # return the data (in this case the error message) as well as the setting for which library to use
                    return {'chart_library': chart_library, 'data': return_output,
                            'chart_external_scripts': chart_external_scripts}

                try:
                    # check if server and library paths are reachable
                    # choose connection based on scheme
                    if moloewe_url.scheme == 'https':
                        moloewe_server_connection = http.client.HTTPSConnection(moloewe_url.netloc)
                    else:
                        moloewe_server_connection = http.client.HTTPConnection(moloewe_url.netloc)
                    # check if server and moloewe library path are reachable
                    moloewe_server_connection.request("HEAD", moloewe_library_moloewe_path + 'moloewe-chart.js')
                    moloewe_server_status = moloewe_server_connection.getresponse().status
                    # check for error and create error message text
                    if not moloewe_server_status == 200:
                        chart_html_template = chart_html_template_notebook_error
                        moloewe_error_message = 'Error: ' + str(
                            moloewe_server_status) + ' Could not verify that server ' + moloewe_server + ' has moloewe chart library installed.'
                        # insert error message into html template
                        tmp_string = ''''''
                        tmp_string = tmp_string.join(map(str, moloewe_error_message))
                        chart_html_template = chart_html_template.replace('<!-- #moloewe_error_message# -->',
                                                                          str(tmp_string))

                        # generate html output
                        html_output = getmembers(HTML(chart_html_template))
                        # generate return result
                        return_output = dict(html_output)['__dict__']['data']

                        # return the data (in this case the error message) as well as the setting for which library to use
                        return {'chart_library': chart_library, 'data': return_output,
                                'chart_external_scripts': chart_external_scripts}

                except Exception as ex:
                    chart_html_template = chart_html_template_notebook_error
                    # create create error message text for exception
                    moloewe_error_message = 'Error: ' + str(
                        ex) + ' Trying to contact server ' + moloewe_server + moloewe_library_echarts_path + 'moloewe-chart.js to preview chart raised an exception.'
                    # insert error message into html template
                    tmp_string = ''''''
                    tmp_string = tmp_string.join(map(str, moloewe_error_message))
                    chart_html_template = chart_html_template.replace('<!-- #moloewe_error_message# -->',
                                                                      str(tmp_string))

                    # generate html output
                    html_output = getmembers(HTML(chart_html_template))
                    # generate return result
                    return_output = dict(html_output)['__dict__']['data']

                    # return the data (in this case the error message) as well as the setting for which library to use
                    return {'chart_library': chart_library, 'data': return_output,
                            'chart_external_scripts': chart_external_scripts}

            # insert server domain into html template
            tmp_string = ''''''
            tmp_string = tmp_string.join(map(str, moloewe_server))
            chart_html_template = chart_html_template.replace('<!-- #moloewe_server# -->', str(tmp_string))

            # insert library paths into html template
            tmp_string = ''''''
            tmp_string = tmp_string.join(map(str, moloewe_library_echarts_path))
            chart_html_template = chart_html_template.replace('<!-- #moloewe_library_echarts_path# -->',
                                                              str(tmp_string))
            tmp_string = ''''''
            tmp_string = tmp_string.join(map(str, moloewe_library_moloewe_path))
            chart_html_template = chart_html_template.replace('<!-- #moloewe_library_moloewe_path# -->',
                                                              str(tmp_string))

            # insert embedded data variables into html template
            tmp_string = ''''''
            tmp_string = tmp_string.join(map(str, moloewe_embedded_data))
            chart_html_template = chart_html_template.replace('<!-- #moloewe_embedded_data# -->', str(tmp_string))

            # insert preset chart options into html template
            tmp_string = ''''''
            tmp_string = tmp_string.join(map(str, moloewe_preset_options))
            chart_html_template = chart_html_template.replace('<!-- #moloewe_preset_options# -->',
                                                              str(tmp_string) + ';')

            # insert chart options into html template
            tmp_string = ''''''
            tmp_string = tmp_string.join(map(str, moloewe_options))
            chart_html_template = chart_html_template.replace('<!-- #moloewe_options# -->', str(tmp_string) + ';')

            # insert chart scripts into html template
            tmp_string = ''''''
            tmp_string = tmp_string.join(map(str, moloewe_scripts))
            chart_html_template = chart_html_template.replace('<!-- #moloewe_scripts# -->', str(tmp_string) + ';')

            # insert chart scripts postprocess into html template
            tmp_string = ''''''
            tmp_string = tmp_string.join(map(str, moloewe_scripts_postprocess))
            chart_html_template = chart_html_template.replace('<!-- #moloewe_scripts_postprocess# -->',
                                                              str(tmp_string) + ';')

            # insert chart scripts preprocess into html template
            tmp_string = ''''''
            tmp_string = tmp_string.join(map(str, moloewe_scripts_preprocess))
            chart_html_template = chart_html_template.replace('<!-- #moloewe_scripts_preprocess# -->',
                                                              str(tmp_string) + ';')

            # insert timestamp to prevent caching into html template
            tmp_string = ''''''
            tmp_string = moloewe_random
            chart_html_template = chart_html_template.replace('<!-- #moloewe_random# -->', str(tmp_string))

            # generate html output
            html_output = getmembers(HTML(chart_html_template))
            # generate return result
            return_output = dict(html_output)['__dict__']['data']

        # create return result for chart using plotly
        if chart_library == 'plotly':
            return_output = plotly_data

        # return the data as well as the setting for which library to use
        return {'chart_library': chart_library, 'data': return_output, 'chart_external_scripts': chart_external_scripts}

    # render chart preview in JupyterHub notebook (for echarts and plotly graphs)
    def moloewe_plot_preview(self, moloewe_plot_function):
        # check if function is called within JupyterHub or from MoLöWe and run only if called within JupyterHub
        if not self.moloewe_executed_in_moloewe:
            # based on value in chart_library render data in the notebook
            if moloewe_plot_function['chart_library'] == 'echarts':
                from IPython.display import HTML
                return HTML(moloewe_plot_function['data'])
            elif moloewe_plot_function['chart_library'] == 'plotly':
                from plotly import graph_objects as go
                return go.Figure(moloewe_plot_function['data']).show()

    # render chart preview to file in JupyterHub notebook (for echarts and plotly graphs)
    def moloewe_plot_preview_file(self, moloewe_plot_function, file_name):
        # check if function is called within JupyterHub or from MoLöWe and run only if called within JupyterHub
        if not self.moloewe_executed_in_moloewe:
            # based on value in chart_library render data as html and save to the file
            if moloewe_plot_function['chart_library'] == 'echarts':
                from IPython.display import HTML
                with open(file_name + '.html', 'w') as output_file:
                    output_file.write(str(moloewe_plot_function['data']))
            elif moloewe_plot_function['chart_library'] == 'plotly':
                from plotly import graph_objects as go
                go.Figure(moloewe_plot_function['data']).write_html(file_name + '.html')                   

    # add options (pyhton dicttionary elements) to a python dictionary of settings for the chart
    def moloewe_chart_add_options(self, moloewe_chart_options, my_options):
        moloewe_chart_options.update(my_options)
        return moloewe_chart_options

    #  remove extra options from python dictionary
    def moloewe_chart_remove_options(self, moloewe_chart_options, my_options):
        # check if my_options exist in moloewe_chart_options python dict
        # remove my_options from moloewe_chart_options python dict if it does exist
        if my_options in moloewe_chart_options.keys():
            del moloewe_chart_options[my_options]
        return moloewe_chart_options

    #  update extra options in python dictionary
    def moloewe_chart_update_options(self, moloewe_chart_options, removable_option_key, my_options):
        moloewe_chart_options = self.moloewe_chart_remove_options(moloewe_chart_options, removable_option_key)
        moloewe_chart_options = self.moloewe_chart_add_options(moloewe_chart_options, my_options)
        return moloewe_chart_options

    # convert python dictionary of options to a JSON object for exporting
    def moloewe_chart_convert_options_json(self, my_options):
        import json
        return json.dumps(my_options)

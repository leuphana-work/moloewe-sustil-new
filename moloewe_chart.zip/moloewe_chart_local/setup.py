from setuptools import setup

setup(name='moloewe_chart',
      version='1.5',
      description='A collection of helper functions for MobileSolutionWorkshop / MobileLösungsWerkstatt',
      url='#',
      author='Leuphana University Lueneburg',
      author_email='',
      license='',
      packages=['moloewe_chart'],
      zip_safe=False)
